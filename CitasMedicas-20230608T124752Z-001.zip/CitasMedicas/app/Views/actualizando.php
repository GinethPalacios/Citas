<!DOCTYPE html>
<html>
<head>
  <title>Actualizacion de Persona</title>
  
</head>
<body>

<style>
body {
    font-family: Arial, sans-serif;
    background-color: #a6c6d8;
    padding: 20px;
  }
  
  
  h2 {
    color: #000000;
    text-align:center;
    font-family: Arial, sans-serif;
  }
  
  form {
    background-color: #d2d6f8;
    padding: 70px;
    border-radius: 20px;
    box-shadow: 0 2px 5px rgb(0, 0, 0);
    width: 200px;
    margin: 0 auto;
  }
  
  label {
    display: block;
    font-weight: bold;
    margin-bottom: 4px;
  }
  
  input[type="text"],
  input[type="password"] {
    width: 100%;
    padding: 10px;
    border: 1px solid #bfc3c5;
    border-radius: 4px;
    margin-bottom: 10px;
  }
  
  input[type="submit"] {
    background-color: #031a58;
    color: rgb(217, 232, 233);
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
  }
  
  input[type="submit"]:hover {
    background-color: #75cbd6;
  }
  
</style>




  <h2>Actualizacion de Persona</h2>
  
  <form action="<?= base_url('factualizar'); ?>" method="POST">
  <input type="number" hidden name="id" value="<?= $usuario['id'] ?>">

    <label for="usuario">Usuario:</label>
    <input type="text" id="usuario" name="usuario"  value="<?= $usuario['usuario'] ?>" required><br><br>

    <label for="contraseña">Contraseña:</label>
    <input type="text" id="contraseña" name="contraseña"  value="<?= $usuario['contraseña'] ?>" required><br><br>

    <label for="nombre">Nombre:</label>
    <input type="text" id="nombre" name="nombre"  value="<?= $usuario['nombre'] ?>" required><br><br>

    <label for="apellido">Apellido:</label>
    <input type="text" id="apellido" name="apellido" value="<?= $usuario['apellido'] ?>" required><br><br>

    <label for="tipoDocumento">Tipo Documento:</label>
    <input type="text" id="tipoDocumento" name="tipoDocumento" value="<?= $usuario['tipoDocumento'] ?>" required><br><br>


    <label for="documento">Documento:</label>
    <input type="number" id="documento" name="documento" value="<?= $usuario['documento'] ?>"required><br><br>

    <label for="telefono">Telefono:</label>
    <input type="number" id="telefono" name="telefono" value="<?= $usuario['telefono'] ?>"required><br><br>

    
    <button type="submit" class="btn btn-info">Actualizar</button>
    <br>
    <br> 
    <a href="http://localhost/CitasMedicas/public/">Volver</a>
  </form>
</body>
</html>








