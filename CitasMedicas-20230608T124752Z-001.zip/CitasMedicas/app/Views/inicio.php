
<!DOCTYPE html>
<html>
<head>
  <title>Inicio de sesión - Citas médicas</title>
  
</head>
<body>
  <h2>Inicio de sesión</h2>
  <form action="procesar_login.php" method="POST">
    <label for="username">Usuario:</label><br>
    <input type="text" id="username" name="username" ><br><br>
    <label for="password">Contraseña:</label><br>
    <input type="password" id="password" name="password" ><br><br>
    <input type="submit" value="Iniciar sesión"> <br><br>
    <p>Si no tienes cuenta, registrate</p>
   
    <a href="<?=base_url('registro')?>">Registrarse</a>
  </form>

